var myaddress = "your public address" // your ETH public Address 
var myprivatekey = "your privatekey to the address" // the privatekey to the ETH address your provided
var myseed = "your wallet seed" //for wallet with no privatekey accessibility example (hardwarewallets) make sure to still provided a ETH public address you want the program to utilize 
var networks = "1" //1 = ETH , 2 = BNB , 3 = POLYGON
var maxspend = "0.5" // max eth you want to spend. Note: Make sure you have that amount in the wallet you provided.

